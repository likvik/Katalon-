<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Ивашин тестовое задание</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>4e11b939-04ee-430f-9b79-ac5005d2e790</testSuiteGuid>
   <testCaseLink>
      <guid>3b3d50b3-ac86-4b4c-91ca-5beb2e7cb93c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Ивашин тестовое задание/Untitled Test Case</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    